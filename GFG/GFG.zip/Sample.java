import java.io.*;

public class Sample{

     public static void main(String []args){

    String string = "This is a string type";
    char[] charArray = {'C', 'h', 'a', 'r', 'a', 'c', 't', 'e', 'r', ' ', 'a', 'r', 'r', 'a', 'y'};

        System.out.println("Hello World\n" + string + "\n" + new String(charArray) + "\n");
     }
}