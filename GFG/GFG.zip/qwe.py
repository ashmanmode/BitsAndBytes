a = 1
a,b=a+1,a+1
print a
print b